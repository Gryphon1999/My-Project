; (function ($) {
    "use strict"


})(jQuery)